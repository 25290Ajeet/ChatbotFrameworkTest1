//
//  NiceLogger.h
//  NiceLogger
//
//  Created by Ajeet Sharma on 16/06/20.
//  Copyright © 2020 Ajeet Sharma. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for NiceLogger.
FOUNDATION_EXPORT double NiceLoggerVersionNumber;

//! Project version string for NiceLogger.
FOUNDATION_EXPORT const unsigned char NiceLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NiceLogger/PublicHeader.h>


